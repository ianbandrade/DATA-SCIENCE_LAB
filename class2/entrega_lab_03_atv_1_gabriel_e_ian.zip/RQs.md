# RQs

Elaboração das cinco perguntas de pesquisa para realizar um estudo com base nos [dados](./data/task_sample.csv) de issues do GitHub

## RQ1

Quais as label que as issues são mais classificadas quando no seu título ou corpo de mensagem apresenta um valor que aparenta ser nome de uma versão, como 1.0, 1.1.0, v1.1.1?

## RQ2

Quais as label que as issues são mais classificadas quando no seu título ou corpo de mensagem termina com um ponto de interrogação?

## RQ3

Quais as label que as issues são mais classificadas quando no seu título ou corpo de mensagem termina com um ponto de exclamação?

## RQ4

Quais as label que as issues são mais classificadas quando no seu título ou corpo de mensagem apresenta a palavra "error" ou "errors"?

## RQ5

Quais as label que as issues são mais classificadas quando no seu título ou corpo de mensagem apresenta a palavra "bug" ou "bugs"?
